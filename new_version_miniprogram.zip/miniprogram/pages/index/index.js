Page({
  data:{
    hello:'欢迎进入'
  },
  onLoad(){

  },
  change: function(){
    this.setData({
      hello:this.data.hello + "~~",
    })
  },
  gameStart(){
    wx.navigateTo({
      url: '/pages/startgame/index',
    })
  },
})