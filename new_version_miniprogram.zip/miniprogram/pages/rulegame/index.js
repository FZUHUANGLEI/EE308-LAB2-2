Page({
  data:{
    hello:'欢迎进入'
  },
  onLoad(){

  },
  submit(){
    wx.navigateTo({
      url: '/pages/gameover/index',
    })
  },
})