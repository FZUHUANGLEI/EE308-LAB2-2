Page({
  data: {
    ins: 1,
  },
  onLoad(){

},
keys(e){
  this.setData({
    ins: e.detail.value
  })
},
  tz(){
    wx.navigateTo({
      url:'/pages/roll/index?ID='+this.data.ins,
    })
  }
})