Page({
  // data:{
  //   hello:'欢迎进入'
  // },
  onLoad(){
  },
  backIndex(){
    wx.reLaunch({
      url: '/pages/index/index',
    })
    
  },
  // change: function(){
  //   this.setData({
  //     hello:this.data.hello + "~~",
  //   })
  // },
})